package com.cloud;

import org.springframework.web.client.RestTemplate;

import javax.sound.midi.Soundbank;

/**
 * @author 蔡学亮(caixueliang@shoujinwang.com)
 * @date 2018年03月16日 16:43
 */
public class Main {
    public static void main(String[] args) {

//        RestTemplate restTemplate = new RestTemplate();
//        String queryParam = "";
//        String result = restTemplate.getForObject("http://localhost:8027/fundclient/shoujin/queryWindControl?param=" + queryParam, String.class);
        double aDouble= Double.valueOf("1.123");
        System.out.println(aDouble);
    }
}
