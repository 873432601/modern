package com.cloud.leon.poi;

import java.io.Serializable;

/**
 * 相片的元数据实体类
 *
 * @author 蔡学亮(caixueliang@shoujinwang.com)
 * @date 2018年03月14日 15:34
 */
public class ImageMetadata implements Serializable{
    /**
     * 相片高度
     */
    private String imageHeight;
    /**
     * 相片宽度
     */
    private String imageWidth;
    /**
     * 拍摄时间
     */
    private String dateTime;
    /**
     * 位置经度
     */
    private String longitude;
    /**
     * 位置纬度
     */
    private String latitude;
    /**
     * 位置高度
     */
    private String altitude;

    @Override
    public String toString() {
        return "ImageMetadata{" +
                "imageHeight='" + imageHeight + '\'' +
                ", imageWidth='" + imageWidth + '\'' +
                ", dateTime='" + dateTime + '\'' +
                ", longitude='" + longitude + '\'' +
                ", latitude='" + latitude + '\'' +
                ", altitude='" + altitude + '\'' +
                '}';
    }

    public String getImageHeight() {
        return imageHeight;
    }

    public String getImageWidth() {
        return imageWidth;
    }

    public String getDateTime() {
        return dateTime;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getAltitude() {
        return altitude;
    }

    public void setImageHeight(String imageHeight) {

        this.imageHeight = imageHeight;
    }

    public void setImageWidth(String imageWidth) {
        this.imageWidth = imageWidth;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public void setAltitude(String altitude) {
        this.altitude = altitude;
    }
}
