package com.cloud.leon.datahandle;

import com.sun.org.apache.bcel.internal.generic.BREAKPOINT;
import com.sun.org.apache.xpath.internal.WhitespaceStrippingElementMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

/**
 * Json格式化工具类
 * @author 蔡学亮(caixueliang@shoujinwang.com)
 * @date 2018年03月16日 17:06
 */
public class JsonFormatUtils {

    public static void main(String[] args) {
        formatJson(null);
    }

    public static final void formatJson(File file){
        if (!file.exists()) {
            throw new RuntimeException("指定文件：{"+file.getAbsolutePath()+"}不存在");
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            String str  = br.readLine();
            while (str!=null){
                str = str.replace(" ", "");
                str = str.replace("\n", "");
                str = str.replace("\r", "");
                str = str.replace("\b", "");
                str = str.replace("\t", "");
                str = str.replace("\"", "");
                str = str.replace("\\s'", "");
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 断点标志
     */
    private static final boolean BREAK_POINT = true;
    private static final Logger LOGGER = LoggerFactory.getLogger(JsonFormatUtils.class);
}
