package com.cloud.leon.poi;

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.Tag;
import net.sf.json.JSONObject;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.Map;

/**
 * @author 蔡学亮(caixueliang@shoujinwang.com)
 * @date 2018年03月07日 23:50
 */
public class MapUtils {

    /**
     * 解析图片路径
     */
    private static final String filePath = "D:\\image\\工作地点.jpg";
    /**
     * 腾讯地图查询URL
     */
    private static String mapUrl = "http://apis.map.qq.com/ws/geocoder/v1/?location=${LONGITUDE},${LATITUDE}&key=${KEY}&get_poi=1";
    /**
     * 腾讯key
     */
    private static final String KEY = "WOGBZ-4U6KG-556QH-IXUDO-K6242-AZFNL";
    /**
     * 回传数据格式，支持xml|json
     */
    private static final String OUTPUT = "json";

    /**
     * 测试方法
     *
     * @param args
     * @throws ImageProcessingException
     * @throws IOException
     */
    public static void main(String[] args) throws ImageProcessingException, IOException {
        // 获取照片元数据信息实体类
        ImageMetadata imageMetadata = getMapName(filePath);
        // 获取坐标json对象
        JSONObject jsonObject = getMapName(imageMetadata.getLatitude(), imageMetadata.getLongitude());
        System.out.println(jsonObject.toString());
    }

    /**
     * 根据坐标获取地点json数据
     *
     * @param latitude
     * @param longitude
     * @return
     */
    public static final JSONObject getMapName(String longitude, String latitude) {
        // 替换参数
        mapUrl = mapUrl.replace("${LONGITUDE}", longitude);
        mapUrl = mapUrl.replace("${LATITUDE}", latitude);
        //获取响应消息实体
        JSONObject resultJson = null;
        try {
            LOGGER.info("请求url：{}",mapUrl);
            String resultStr = getUrlResult(mapUrl);
            resultJson = JSONObject.fromObject(resultStr);
            LOGGER.info(resultStr);
        } catch (IOException e) {
            LOGGER.error("解析错误:{}", e);
        }
        mapUrl.replace(latitude, "${LONGITUDE}");
        mapUrl.replace(longitude, "${LONGITUDE}");
        return resultJson;
    }

    /**
     * 查询照片元数据将其转换为json
     *
     * @param imagePath
     * @return json格式的照片数据
     * @throws ImageProcessingException
     * @throws IOException
     */
    public static final ImageMetadata getMapName(String imagePath) throws ImageProcessingException, IOException {
        File file = new File(imagePath);
        if (!file.exists()){
            throw new RuntimeException("找不到图片！请检查路径："+imagePath);
        }
        Metadata metadata = ImageMetadataReader.readMetadata(file);
        LOGGER.info("metadata照片元数据数量：" + metadata.getDirectoryCount());
        ImageMetadata imageMetadata = new ImageMetadata();
        for (Directory directory : metadata.getDirectories()) {
            for (Tag tag : directory.getTags()) {
                //标签名
                String tagName = tag.getTagName();
                //标签信息
                String desc = tag.getDescription();
                if (tagName.equals("Image Height")) {
                    imageMetadata.setImageHeight(desc);
                } else if (tagName.equals("Image Width")) {
                    imageMetadata.setImageWidth(desc);
                } else if (tagName.equals("Date/Time Original")) {
                    imageMetadata.setDateTime(desc);
                } else if (tagName.equals("GPS Longitude")) {
                    imageMetadata.setLongitude(MapUtils.pointToLatlong(desc));
                } else if (tagName.equals("GPS Latitude")) {
                    imageMetadata.setLatitude(MapUtils.pointToLatlong(desc));
                } else if (tagName.equals("GPS Altitude")) {
                    imageMetadata.setAltitude(desc);
                }
            }
        }
        return imageMetadata;
    }

    /**
     * 坐标全部转换为度
     *
     * @param point 度分秒的坐标值
     * @return 以度表示坐标值
     */
    public static final String pointToLatlong(String point) {
        Double du = Double.parseDouble(point.substring(0, point.indexOf("°")).trim());
        Double fen = Double.parseDouble(point.substring(point.indexOf("°") + 1, point.indexOf("'")).trim());
        Double miao = Double.parseDouble(point.substring(point.indexOf("'") + 1, point.indexOf("\"")).trim());
        Double duStr = du + fen / 60 + miao / 60 / 60;
        LOGGER.info("坐标转换后：{}",duStr);
        return duStr.toString();
    }

    /**
     * 获取指定url结果
     *
     * @param url 指定的url
     * @return
     */
    public static final String getUrlResult(String url) throws IOException {
        HttpGet httpGet = new HttpGet(url);
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        CloseableHttpClient closeableHttpClient = httpClientBuilder.build();
        HttpResponse httpResponse = closeableHttpClient.execute(httpGet);
        String result = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
        return result;
    }
    static {
        mapUrl = mapUrl.replace("${OUTPUT}", OUTPUT);
        mapUrl = mapUrl.replace("${KEY}", KEY);
    }
    // TODO post请求方法
    private static final Logger LOGGER = LoggerFactory.getLogger("MapUtils");
}
